@echo off
cd /d "%~dp0"

:: First argument is the Interview ID
set INTERVIEW_ID=%1

:: Run EXE with ONLY interview id
start "" "system_check.exe" --interview-id %INTERVIEW_ID%

exit
